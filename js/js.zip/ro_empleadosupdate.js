if(document.getElementById('ro_empleadoscustom')){
    
    //Archivo exclusivo para modificar los registros de empleados
    
    $(document).ready(function(){
        
        $("#identificador").change(function () { 
            var ruc = $(this).val();
            $.ajax({
                url: 'index.php?action=validaRuc',
                type: 'GET',
                data: {ruc: ruc},
                success: function (e) {
                    if (e == 0) {
                        alert('Identificacion ingresada incorrecta..!!!')
                        $("#identificador").val('');
                        $('#identificador').focus();
                    }
                }
            })
        });
    
        $("#nacimiento").blur(function(){
            var edad = $(this).val();
            $.ajax({
                url:'./?action=ro_processempleadosedad',
                type:'GET',
                data: {edad:edad},
                success:function(e){
                    if(e==0){
                        alert('La fecha de nacimiento no cumple con la mayoría de edad establecida...!!!')
                        $("#nacimiento").val('');
                        $("#nacimiento").focus();
                    }
                }
            })
        })
        
        function loadgrupoetnico(){
            let ct = ''
             if(document.getElementById('etnico')){
                 ct = $("#etnico").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:1},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                
                $.each(res, function(i, item){
                    if (ct != ''){
                            if (ct == item.id){
                                selected = "selected"
                            }else{
                                selected=''
                            }
                        }
                    viewHTML += '<option value="' +item.id + '"' +selected+'>' + item.name + '</option>'
                })
                $("#etnia").html(viewHTML)
                
            }
        })
        }
        loadgrupoetnico()
        
        function loadprofesion(){
            let ct = ''
             if(document.getElementById('pro')){
                 ct = $("#pro").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:5},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                
                $.each(res, function(i, item){
                    if(ct !== ''){
                        if(ct == item.id){
                            selected = "selected"
                        }else{
                            selected =''
                        }
                    }
                    viewHTML += '<option value="' +item.id + '"' +selected+ '>' + item.name + '</option>'
                })
                $("#profesion").html(viewHTML)
                
                
            }
        })
        }
        loadprofesion()
        
        function loadnacion(){
            let ct = ''
            if(document.getElementById('nacion')){
                 ct = $("#nacion").val()
            }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:6},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if (ct !== ''){
                            if (ct == item.id){
                                selected = "selected"
                            }else{
                                selected =''
                            }
                        }
                    viewHTML += '<option value="' +item.id+ '"' +selected+ '>' + item.name + '</option>'
                })
                $("#nacionalidad").html(viewHTML)
            }
        })
        }
        loadnacion()
        
        function loadtipo(){
            let ct = ''
             if(document.getElementById('empleado')){
                 ct = $("#empleado").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:7},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if(ct !== ''){
                        if(ct == item.id){
                            selected = "selected"
                        }else{
                            selected = ''
                        }
                    }
                    viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                })
                $("#tiemp").html(viewHTML)
                
                
            }
        })
        }
        loadtipo()
        
        function loadcargo(){
            let ct = ''
             if(document.getElementById('cargos')){
                 ct = $("#cargos").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:8},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if(ct !== ' '){
                        if(ct==item.id){
                            selected = "selected"
                        }else{
                            selected =''
                        }
                    }
                    viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                })
                $("#cargo").html(viewHTML)
            }
        })
        }
        loadcargo()
        
        function loadrol(){
            let ct = ''
             if(document.getElementById('rol')){
                 ct = $("#rol").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:9},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if(ct !== ''){
                        selected = "selected"
                    }else{
                        selected = ''
                    }
                    viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                })
                $("#tiro").html(viewHTML)
                
                
            }
        })
        }
        loadrol()
        
        let roltipo = $("#rol").val()
        loaddatarol(roltipo)
        function loaddatarol(roltipo){
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:28, roltipo:roltipo},
                success:function(respond){
                    let res = JSON.parse(respond)
                    $("#peid").val(res[0])
                    $("#tranioact").val(res[1])
                    $("#caid").val(res[2])
                }
            })
        }
        
        
        function loadformacion(){
            let ct = ''
            if(document.getElementById('academia')){
                ct = $("#academia").val()
            }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:10},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if(ct!==''){
                        if(ct==item.id){
                            selected = "selected"
                        }else{
                            selected =''
                        }
                    }
                    viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                })
                $("#forad").html(viewHTML)
                
                
            }
        })
        }
        loadformacion()
        
        function loadentidades(){
            let ct = ''
             if(document.getElementById('etb')){
                 ct = $("#etb").val()
             }
            $.ajax({
            url:'./?action=ro_processempleadosData',
            type:'POST',
            data:{option:11},
            success:function(respond){
                let res = JSON.parse(respond)
                let viewHTML= '<option value="">Seleccione...</option>'
                let selected=''
                $.each(res, function(i, item){
                    if(ct!==''){
                        if(ct==item.id){
                            selected="selected"
                        }else{
                            selected =''
                        }
                    }
                    viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                })
                $("#entidades").html(viewHTML)
                
                
            }
        })
        }
        loadentidades()
        
        function loadetiquetas(){
            let etqs = ''
             if(document.getElementById('etqs')){
                 etqs = $("#etqs").val()
             }
            let etqConfig = $("#configInv").val()
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:12,etqConfig:etqConfig},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML= '<option value="">Seleccione...</option>'
                    let selected=''
                    //$.each(res, function(i, item){
                        if(etqs!==''){
                            if(etqs==res.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML += '<option value="' +res.id + '"'+selected+'>' + res.name + '</option>'
                    //})
                    $("#etiqueta").html(viewHTML)
                }
            })
        }
        loadetiquetas()
        
        let etq = $("#etqs").val()
        loadsubetq(etq)
        
        function loadsubetq(etq){
            let sbta = ''
            if(document.getElementById('subetq')){
                sbta = $("#subetq").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:17,etq:etq},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML= '<option value="">Seleccione...</option>'
                    let selected=''
                    $.each(res, function(i, item){
                        if(sbta!==''){
                            if(sbta==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                    })
                    $("#subetiqueta").html(viewHTML)
                }
            }) 
        }
        
        let etiqueta = $("#etqs").val()
        loadfcrc(etq)
        
        function loadfcrc(etq){
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:18,etq:etq},
                success:function(respond){
                    let res = JSON.parse(respond)
                    if(res.unidades){
                        let uds =''
                        if(document.getElementById('unegocio')){
                            uds = $("#unegocio").val()
                        }
                        let htmlUnidades = '<option value="">Seleccione...</option>'
                        let selected=''
                        $.each(res.unidades, function(i, item){
                            if(uds!==''){
                                if(uds==item.id){
                                    selected="selected"
                                }else{
                                    selected=''
                                }
                            }
                            htmlUnidades += '<option value="' + item.id + '"'+selected+'>' + item.name + '</option>'
                        })
                        $("#unidad").html(htmlUnidades)
                    }
                    if(res.funciones){
                        let fcn =''
                        if(document.getElementById('funciones')){
                            fcn = $("#funciones").val()
                        }
                        let htmlFunciones= '<option value="">Seleccione...</option>'
                        let selected=''
                        $.each(res.funciones, function(i, item){
                            if(fcn!==''){
                                if(fcn==item.id){
                                    selected="selected"
                                }else{
                                    selected=''
                                }
                            }
                            htmlFunciones += '<option value="' +item.id + '"'+selected+'>' + item.name + '</option>'
                        })
                        $("#funcion").html(htmlFunciones)
                    }
                }
            })
        }
        
        let ctrcst = $("#unegocio").val()
        loadcostos(ctrcst)
        
        function loadcostos(ctrcst){
            let costocn = ''
            if(document.getElementById('centro')){
                costocn = $("#centro").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:19, ctrcst:ctrcst},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i, item){
                        if(costocn!==''){
                            if(costocn==item.id){
                                selected = "selected"
                            }else{
                                selected = ''
                            }
                        }
                        viewHTML+='<option value="' + item.id + '"' +selected+'>' +item.name+ '</option>'
                    })
                    $("#centrocosto").html(viewHTML)
                }
            })
        }
        
        $("#matrimonio").change(function(){
            let id= $(this).val()
            if(id==2){
                $("#emmatrimonio").removeAttr('disabled')
                $("#emconyuge").removeAttr('disabled')
                $("#emcon_trabaja").removeAttr('disabled')
            }else{
                $("#emmatrimonio").attr('disabled', true)
                $("#emconyuge").attr('disabled', true)
                $("#emcon_trabaja").attr('disabled', true)   
            }
        })
        
        let td = $("#pareja").val()
        listenEstadoCivil(td)
        function listenEstadoCivil(td){
            // let td = $(this).va()
            if(td==2){
                $("#emmatrimonio").removeAttr('disabled')
                $("#emconyuge").removeAttr('disabled')
                $("#emcon_trabaja").removeAttr('disabled')
            }else{
                $("#emmatrimonio").attr('disabled', true)
                $("#emconyuge").attr('disabled', true)
                $("#emcon_trabaja").attr('disabled', true)
            }
        }
        
        $("#discapacidad").change(function(){
            let discapacidad = $(this).val()
            if(discapacidad==1){
                $("#empdiscap").removeAttr('disabled')
            }else{
                $("#empdiscap").attr('disabled', true)
            }
        })
        
        let dp = $("#diselect").val()
        iddiscapacidad(dp)
        function iddiscapacidad(dp){
            if(dp==1){
                $("#empdiscap").removeAttr('disabled')
            }else{
                $("#empdiscap").attr('disabled', true)
            }
        }
        
        $("#paisnac").change(function () {
            let pais = $('#paisnac option:selected').html()
            if (pais !== "ECUADOR") {
                $("#cdnac").attr('disabled', true)
                $("#provnac").attr('disabled', true)
            } else {
                $("#cdnac").removeAttr('disabled')
                $("#provnac").removeAttr('disabled')
            }
        })
        
        function loadpaisesnac(){
            let pais =''
            if(document.getElementById('paiso')){
                pais=$("#paiso").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:2},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i, item){
                        if(pais!==''){
                            if(pais==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML+='<option value="' + item.id + '"' +selected+'>' +item.name+ '</option>'
                    })
                    $("#paisnac").html(viewHTML)
                }
            })
        }
        
        loadpaisesnac()
        
        let naciprov = $("#paiso").val()
        loadprovincianac(naciprov)
        
        function loadprovincianac(naciprov){
            let prov=''
            if(document.getElementById('nacprov')){
                prov = $("#nacprov").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:23, naciprov:naciprov},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected=''
                    $.each(res, function(i,item){
                        if(prov!==''){
                            if(prov==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML +='<option value="' +item.id+'"'+selected+'>'+item.name+'</option>'
                    })
                    $("#provnac").html(viewHTML)
                }
            })
        }
        
        let cddatosnac = $("#nacprov").val()
        loadcdnac(cddatosnac)
        function loadcdnac(cddatosnac){
            let cd=''
            if(document.getElementById('ciudad')){
                cd = $("#ciudad").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:24,cddatosnac:cddatosnac},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i,item){
                        if(cd!==''){
                            if(cd==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML +='<option value="' +item.id+'"'+selected+'>'+item.name+'</option>'
                    })
                    $("#cdnac").html(viewHTML)
                }
            })
        }
        
        $("#paisdom").change(function () {
            let pais = $('#paisdom option:selected').html()
            if (pais !== "ECUADOR") {
                $("#cddom").attr('disabled', true)
                $("#provdom").attr('disabled', true)
            } else {
                $("#cddom").removeAttr('disabled')
                $("#provdom").removeAttr('disabled')
            }
        })
        
        $("#paisdom").change(function () {
            let pais = $('#paisdom option:selected').html()
            if (pais !== "ECUADOR") {
                $("#cddom").attr('disabled', true)
                $("#provdom").attr('disabled', true)
            } else {
                $("#cddom").removeAttr('disabled')
                $("#provdom").removeAttr('disabled')
            }
        })
        
        function loadpaisesdom(){
            let pais =''
            if(document.getElementById('dompais')){
                pais=$("#dompais").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:20},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i, item){
                        if(pais!==''){
                            if(pais==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML+='<option value="' + item.id + '"' +selected+'>' +item.name+ '</option>'
                    })
                    $("#paisdom").html(viewHTML)
                }
            })
        }
        
        loadpaisesdom()
        
        
        $(document).on('change', '#paisdom', function(){
            let provdatadom  = $(this).val()
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:21, provdatadom:provdatadom},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    $.each(res, function(i,item){
                        viewHTML +='<option value="' +item.id+'">'+item.name+'</option>'
                    })
                    $("#provdom").html(viewHTML)
                }
            })
        })
        
        $(document).on('change', '#provdom', function(){
            let cddatadom = $(this).val()
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:22,cddatadom:cddatadom},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    $.each(res, function(i,item){
                        viewHTML +='<option value="' +item.id+'">'+item.name+'</option>'
                    })
                    $("#cddom").html(viewHTML)
                }
            })
        })
        
        
        function loadpaisesdom(){
            let pais =''
            if(document.getElementById('dompais')){
                pais=$("#dompais").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:20},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i, item){
                        if(pais!==''){
                            if(pais==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML+='<option value="' + item.id + '"' +selected+'>' +item.name+ '</option>'
                    })
                    $("#paisdom").html(viewHTML)
                }
            })
        }
        
        loadpaisesdom()
        
        let provdom = $("#dompais").val()
        loadprovinciadom(provdom)
        
        function loadprovinciadom(provdom){
            let prv=''
            if(document.getElementById('domprov')){
                prv = $("#domprov").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:25, provdom:provdom},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected=''
                    $.each(res, function(i,item){
                        if(prv!==''){
                            if(prv==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML +='<option value="' +item.id+'"'+selected+'>'+item.name+'</option>'
                    })
                    $("#provdom").html(viewHTML)
                }
            })
        }
        
        let domcd = $("#domprov").val()
        loadcddom(domcd)
        function loadcddom(domcd){
            let cd=''
            if(document.getElementById('domcd')){
                cd = $("#domcd").val()
            }
            $.ajax({
                url:'./?action=ro_processempleadosData',
                type:'POST',
                data:{option:26,domcd:domcd},
                success:function(respond){
                    let res = JSON.parse(respond)
                    let viewHTML = '<option value="">Seleccione...</option>'
                    let selected = ''
                    $.each(res, function(i,item){
                        if(cd!==''){
                            if(cd==item.id){
                                selected="selected"
                            }else{
                                selected=''
                            }
                        }
                        viewHTML +='<option value="' +item.id+'"'+selected+'>'+item.name+'</option>'
                    })
                    $("#cddom").html(viewHTML)
                }
            })
        }
        
        function inputFile(input){
            if(input.files && input.files[0]){
                var reader = new FileReader()
                
                reader.onload = function(e){
                    //$('#form-ro_empleados + image').remove()
                    $('#miniwindow').html('<img src="'+e.target.result+'" width="145" height="100" align="center"/> ')
                }
                reader.readAsDataURL(input.files[0])
            }
        }
        $("#foto").change(function(){
            inputFile(this)
        })
        
        
        
        $("#save-modified-ro_empleados").click(function(e){
            let nombre = $("#emnombre").val()
            if(nombre.length==0){
                Swal.fire({
                    icon:'error',
                    title:'Ingrese su nombre',
                })
            }else{
               let apellido = $("#emapellido").val()
               if(apellido.length==0){
                   Swal.fire({
                       icon:'error',
                       title:'Ingrese su apellido',
                   })
               }else{
                   let legal = $("#identificador").val()
                   if(legal.length==0){ 
                       Swal.fire({
                           icon:'error',
                           title:'Ingrese su cédula',
                       })
                   }else{
                       let fecnac = $("#nacimiento").val()
                       if(fecnac.length==0){
                           Swal.fire({
                               icon:'error',
                            title:'Ingrese su fecha de nacimiento',
                           })
                       }else{
                           let calle = $("#emdom_calle").val()
                           if(calle.length==0){
                               Swal.fire({
                                   icon:'error',
                               title:'Ingrese su dirección',
                               })
                           }else{
                                let vivienda = $("#emdom_num").val()
                                if(vivienda.length==0){
                                    Swal.fire({
                                        icon:'error',
                                        title:'Ingrese el número de vivienda',
                                    })
                                }else{
                                    let telefono = $("#emdom_fono1").val()
                                    if(telefono.length==0){
                                        Swal.fire({
                                            icon:'error',
                                            title:'Ingrese su número de telefono',
                                        })
                                    }else{
                                        let celular = $("#emcelular").val()
                                        if(celular.length==0){
                                            Swal.fire({
                                                icon:'error',
                                                title:'Ingrese su número celular',
                                            })
                                        }else{
                                            let correo = $("#emmail").val()
                                            if(correo.length==0){
                                                Swal.fire({
                                                    icon:'error',
                                                    title:'Ingrese su correo electrónico'
                                                })
                                            }else{
                                                let datos = new FormData(document.getElementById('form-ro_empleados'))
                                                $.ajax({
                                                     url:'./?action=ro_processempleados',
                                                     type:'POST', 
                                                     data: datos,
                                                     contentType:false,
                                                     cache:false,
                                                     processData: false,
                                                     success:function(respond){
                                                         let res = JSON.parse(respond)
                                                         if(res.substr(0,1)==0){
                                                             Swal.fire({
                                                                 icon:'error',
                                                                 title:res.substr(2),
                                                             })
                                                         }else{
                                                             Swal.fire({
                                                                 icon:'success',
                                                                 title:res.substr(2),
                                                             }).then((result)=>{
                                                                 if(result.isConfirmed){
                                                                     location.href='./?view=ro_viewempleados'
                                                                }
                                                            })
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    }
                                }               
                            }
                        }
                    }
                }
            }
        })
        
    })
    
}